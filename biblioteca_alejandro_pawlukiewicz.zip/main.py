from conexion import Conectar
from libro import *
from acceso_datos import Acceso
from lector import Lectores
from prestamo import Prestamos

def menu(): #Esta función es la que se encarga de mostrar el menú de la biblioteca.
    print("\nBIENVENIDO A LA BIBLIOTECA\n")
    print("1. Añadir un libro")
    print("2. Ver los libros")
    print("3. Buscar un libro")
    print("4. Eliminar un libro")
    print("5. Modificar un libro")
    print("6. Prestar un libro")
    print("7. Devolver un libro")
    print("8. Añadir un lector")
    print("9. Ver los lectores")
    print("10. Buscar un lector")
    print("11. Eliminar un lector")
    print("12. Modificar un lector")
    print("13. Añadir un préstamo")
    print("14. Ver los préstamos")
    print("15. Buscar un préstamo")
    print("16. Eliminar un préstamo")
    print("17. Modificar un préstamo")
    print("18. Salir")
    opcion = int(input("\nSeleccione una opción: "))
    return opcion

while True: #Este es el bucle que se encarga de ejecutar el programa de la biblioteca.
    conexion = Conectar()
    conexion.conexion_biblioteca()
    opcion = menu()

    if opcion == 1:
        libro = Acceso(conexion)
        libro.anadirlibro()
    elif opcion == 2:
        libro = Acceso(conexion)
        print(libro.verlibros())
    elif opcion == 3:
        libro = Acceso(conexion)
        print(libro.buscarlibro())
    elif opcion == 4:
        libro = Acceso(conexion)
        libro.eliminarlibro()
    elif opcion == 5:
        libro = Acceso(conexion)
        libro.modificarlibro()
    elif opcion == 6:
        libro = Acceso(conexion)
        libro.prestralibro()
    elif opcion == 7:
        libro = Acceso(conexion)
        libro.devolverlibro()
    elif opcion == 8:
        lector = Lectores(conexion)
        lector.anadirlector()
    elif opcion == 9:
        lector = Lectores(conexion)
        print(lector.verlectores())
    elif opcion == 10:
        lector = Lectores(conexion)
        lector.buscarlector()
    elif opcion == 11:
        lector = Lectores(conexion)
        lector.eliminarlector()
    elif opcion == 12:
        lector = Lectores(conexion)
        lector.modificarlector()
    elif opcion == 13:
        prestamo = Prestamos(conexion)
        prestamo.anadirprestamo()
    elif opcion == 14:
        prestamo = Prestamos(conexion)
        print(prestamo.verprestamos())
    elif opcion == 15:
        prestamo = Prestamos(conexion)
        prestamo.buscarprestamo()
    elif opcion == 16:
        prestamo = Prestamos(conexion)
        prestamo.eliminarprestamo()
    elif opcion == 17:
        prestamo = Prestamos(conexion)
        prestamo.modificarprestamo()
    elif opcion == 18:
        print("\nMuchas gracias por usar la biblioteca.\n")
        break
    else:
        print("Opción Incorrecta.")

    conexion.close_connection()
