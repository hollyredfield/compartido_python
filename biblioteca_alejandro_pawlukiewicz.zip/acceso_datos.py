
class Acceso:
    
    def __init__(self, bdd):
        self.bdd = bdd

    def anadirlibro(self): #Esta función es la que se encarga de añadir un libro a la base de datos de la biblioteca y se le pide al usuario que ingrese los datos del libro que desea añadir.
        titulo = input("Dime cual es el titulo del libro:: ")
        autor = input("Quien es su autor: ")
        genero = input("Ingresa el genero del libro: ")
        paginas = int(input("Cuantas paginas tiene el libro: "))
        anio_publicacion = input("Ingresa el año de publicacion del libro: ")
        edicion = input("Cual edicion es: ")
        idioma = input("En que idioma esta escrito: ")
        ISBN = input("Ingrese el ISBN del libro: ")
        prestamos_realizados = int(input("Ingrese el número de préstamos realizados del libro: "))
        prestado = bool(input("El libro está prestado?(s/n): "))
        try:
            cursor = self.bdd.conexion.cursor()
            query = ("INSERT INTO libros " "(titulo, autor, genero, paginas, anio_publicacion, edicion, idioma, ISBN, prestamos_realizados, prestado)" "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)")
            valores = (titulo, autor, genero, paginas, anio_publicacion, edicion, idioma, ISBN, prestamos_realizados, prestado)
            cursor.execute(query, valores)
            self.bdd.conexion.commit()
            cursor.close()
            print("Libro agregado con exito.")
        except ValueError as e:
            print("Error al agregar el libro.",e)

    def verlibros(self): #Esta función es la que se encarga de mostrar los libros que se encuentran en la base de datos de la biblioteca.
        try:
            cursor = self.bdd.conexion.cursor()
            query = ("SELECT titulo, autor, genero, paginas, anio_publicacion, edicion, idioma, ISBN, prestamos_realizados, prestado FROM libros")
            cursor.execute(query)
            for (titulo, autor, genero, paginas, anio_publicacion, edicion, idioma, ISBN, prestamos_realizados, prestado) in cursor:
                print(f"Título: {titulo}, Autor: {autor}, Género: {genero}, Páginas: {paginas}, Año de publicación: {anio_publicacion}, Edición: {edicion}, Idioma: {idioma}, ISBN: {ISBN}, Préstamos realizados: {prestamos_realizados}, Prestado: {prestado}")
            self.bdd.conexion.commit()
            cursor.close()
        except ValueError as e:
            print("Error al mostrar los libros.",e)
        return ""


    def buscarlibro(self): #Esta función es la que se encarga de buscar un libro en la base de datos de la biblioteca.
        try:
            titulo = input("Ingrese el titulo del libro que desea buscar: ")
            cursor = self.bdd.conexion.cursor()
            query = ("SELECT titulo, autor, genero, paginas, anio_publicacion, edicion, idioma, ISBN, prestamos_realizados, prestado FROM libros WHERE titulo = %s")
            cursor.execute(query, (titulo,))
            for (titulo, autor, genero, paginas, anio_publicacion, edicion, idioma, ISBN, prestamos_realizados, prestado) in cursor:
                    print(f"Título: {titulo}, Autor: {autor}, Género: {genero}, Páginas: {paginas}, Año de publicación: {anio_publicacion}, Edición: {edicion}, Idioma: {idioma}, ISBN: {ISBN}, Préstamos realizados: {prestamos_realizados}, Prestado: {prestado}")
            self.bdd.conexion.commit()
            cursor.close()
        except ValueError as e:
            print("Error al buscar el libro.",e)
        return ""
    

    def eliminarlibro(self): #Esta función es la que se encarga de eliminar un libro de la base de datos de la biblioteca.
        try:
            id_libro = input("Ingrese el id del libro que desea eliminar: ")
            cursor = self.bdd.conexion.cursor()
            query = ("DELETE FROM libros WHERE id_libro = %s")
            valores = (id_libro, )
            cursor.execute(query, valores)
            self.bdd.conexion.commit()
            cursor.close()
            print("Libro ha sido eliminado correctamente.")
        except ValueError as e:
            print("Error al eliminar el libro.",e)

    def modificarlibro(self): #Esta función es la que se encarga de modificar un libro de la base de datos de la biblioteca.
        titulo = input("Dime cual es el título del libro que desea modificar: ")
        autor = input("Cual es el nuevo autor del libro: ")
        genero = input("El nuevo género del libro: ")
        paginas = input("Cuantas paginas tiene el nuevo libro: ")
        anio_publicacion = input("En que año se publico: ")
        edicion = input("Cual es la nueva edición del libro: ")
        idioma = input("En que idioma esta escrito el nuevo libro: ")
        ISBN = input("Ingresa el nuevo ISBN del libro: ")
        prestamos_realizados = input("Cual es el numero de prestamos realizados del nuevo libro: ")
        prestado = bool(input("El libro está prestado?(s/n): "))
        try:
            cursor = self.bdd.conexion.cursor()
            query = ("UPDATE libros SET titulo = %s, autor = %s, genero = %s, paginas = %s, anio_publicacion = %s, edicion = %s, idioma = %s, ISBN = %s, prestamos_realizados = %s, prestado = %s WHERE titulo = %s")
            valores = (titulo, autor, genero, paginas, anio_publicacion, edicion, idioma, ISBN, prestamos_realizados, prestado, titulo)
            cursor.execute(query, valores)
            self.bdd.conexion.commit()
            cursor.close()
            print("Libro modificado de forma correcta")
        except ValueError as e:
            print("Error al modificar el libro.",e)

    def prestralibro(self): #Esta función es la que se encarga de prestar un libro de la base de datos de la biblioteca.
        try:
            id_libro = input("Ingrese el id del libro que desea prestar: ")
            cursor = self.bdd.conexion.cursor()
            query = ("UPDATE libros SET prestado = %s WHERE id_libro = %s")
            valores = (True, id_libro)
            cursor.execute(query, valores)
            self.bdd.conexion.commit()
            cursor.close()
            print("El libro fue prestado con exito.")
        except ValueError as e:
            print("Error al prestar el libro.",e)

    def devolverlibro(self): #Esta función es la que se encarga de devolver un libro de la base de datos de la biblioteca.
        try:
            id_libro = input("Ingrese el id del libro que desea devolver: ")
            cursor = self.bdd.conexion.cursor()
            query = ("UPDATE libros SET prestado = %s WHERE id_libro = %s")
            valores = (False, id_libro)
            cursor.execute(query, valores)
            self.bdd.conexion.commit()
            cursor.close()
            print("El libro fue devuelto con exito.")
        except ValueError as e:
            print("Error al devolver el libro.",e)