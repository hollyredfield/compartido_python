
class Prestamos:

    def __init__(self, bdd):
        self.bdd = bdd

    def anadirprestamo(self): #Esta función es la que se encarga de añadir un préstamo a la base de datos de la biblioteca y se le pide al usuario que ingrese los datos del préstamo que desea añadir.
        fecha_prestamo = input("Ingresa cuando se realizo el prestamo: ")
        libro = input("Cual es el nombre del libro: ")
        lector = input("Cual es el nombre del lector: ")
        fecha_devolucion = input("Ingresa cuando se realizo la devolución: ")
        try:
            cursor = self.bdd.conexion.cursor()
            query = ("INSERT INTO prestamos (fecha_prestamo, libro, lector, fecha_devolucion) VALUES (%s, %s, %s, %s)")
            valores = (fecha_prestamo, libro, lector, fecha_devolucion)
            cursor.execute(query, valores)
            self.bdd.conexion.commit()
            cursor.close()
            print("Préstamo agregado con éxito.")
        except ValueError as e:
            print("Error al agregar el préstamo.", e)

    def verprestamos(self): #Esta función es la que se encarga de mostrar los préstamos que se encuentran en la base de datos de la biblioteca.
        try: 
            cursor = self.bdd.conexion.cursor()
            query = ("SELECT fecha_prestamo, libro, lector, fecha_devolucion FROM prestamos")
            cursor.execute(query)
            for (fecha_prestamo, libro, lector, fecha_devolucion) in cursor:
                print(f"Fecha Préstamo: {fecha_prestamo}, Libro: {libro}, Lector: {lector}, Fecha Devolución: {fecha_devolucion}")
            self.bdd.conexion.commit()
            cursor.close()
        except ValueError as e:
            print("Error al mostrar los préstamos.", e)
        return ""

    def buscarprestamo(self): #Esta función es la que se encarga de buscar un préstamo en la base de datos de la biblioteca.
        try:
            libro = input("Ingresa el libro prestado que desea buscar: ")
            cursor = self.bdd.conexion.cursor()
            query = ("SELECT fecha_prestamo, libro, lector, fecha_devolucion FROM prestamos WHERE libro = %s")
            valores = (libro, )
            cursor.execute(query, valores)
            for (fecha_prestamo, libro, lector, fecha_devolucion) in cursor:
                print(f"Fecha Préstamo: {fecha_prestamo}, Libro: {libro}, Lector: {lector}, Fecha Devolución: {fecha_devolucion}")
            self.bdd.conexion.commit()
            cursor.close()
        except ValueError as e:
            print("Error al buscar el préstamo.", e)
        return ""

    def eliminarprestamo(self): #Esta función es la que se encarga de eliminar un préstamo de la base de datos de la biblioteca.
        try:
            id_prestamo = input("Ingresa el id del préstamo que desea eliminar: ")
            cursor = self.bdd.conexion.cursor()
            query = ("DELETE FROM prestamos WHERE id_prestamo = %s")
            valores = (id_prestamo, )
            cursor.execute(query, valores)
            self.bdd.conexion.commit()
            cursor.close()
            print("Préstamo eliminado correctamente.")
        except ValueError as e:
            print("Error al eliminar el préstamo.", e)

    def modificarprestamo(self): #Esta función es la que se encarga de modificar un préstamo de la base de datos de la biblioteca.
        fecha_prestamo = input("Ingresa cuando se realizo el nuevo prestamo: ")
        libro = input("Cual es el nombre del nuevo libro: ")
        lector = input("Cual es el nombre del nuevo lector: ")
        fecha_devolucion = input("Ingresa cuando se realizo la devolución: ")
        try:
            cursor = self.bdd.conexion.cursor()
            query = ("UPDATE prestamos SET fecha_prestamo = %s, libro = %s, lector = %s, fecha_devolucion = %s WHERE fecha_prestamo = %s")
            valores = (fecha_prestamo, libro, lector, fecha_devolucion)
            cursor.execute(query, valores)
            self.bdd.conexion.commit()
            cursor.close()
            print("Préstamo modificado correctamente.")
        except ValueError as e:
            print("Error al modificar el préstamo.", e)