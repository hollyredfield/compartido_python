
class Libros:

    def __init__(self, titulo, autor, editorial, genero,anio_publicacion, paginas, idioma, edicion, prestamos_realizados, ISBN, id_libro): #Esta función es la que se encarga de inicializar los atributos de la clase libros.
        self.titulo = titulo
        self.autor = autor
        self.editorial = editorial
        self.genero = genero
        self.ano_publicacion = anio_publicacion
        self.paginas = paginas
        self.idioma = idioma
        self.prestado = False
        self.devuelto = False
        self.edicion = edicion
        self.prestamos_realizados = prestamos_realizados
        self.isbn = ISBN
        self.id_libro = id_libro
    
    
    def visualizarlibros(self): #Esta función es la que se encarga de mostrar los libros que se encuentran en la base de datos de la biblioteca.
        print(f"Los libros a mostrar son los siguientes: ")
        print(f"Nombre: {self.titulo}")
        print(f"Autor: {self.autor}")
        print(f"Genero: {self.genero}")
        print(f"Editorial: {self.editorial}")
        
    def buscarlibros(self, titulo, autor): #Esta función es la que se encarga de buscar un libro en la base de datos de la biblioteca.
        if self.titulo == titulo or self.autor == autor:
            return True
        return False
    
    def eliminarlibros(self, titulo, id_libro): #Esta función es la que se encarga de eliminar un libro de la base de datos de la biblioteca.
        if self.titulo == titulo or self.id_libro == id_libro:
            return True
        return False
    
    def prestarlibros(self): #Esta función es la que se encarga de prestar un libro de la base de datos de la biblioteca.
        if not self.prestado:
            self.prestado = True
            return True
        return False
    
    def devolverlibros(self): #Esta función es la que se encarga de devolver un libro de la base de datos de la biblioteca.
        if not self.devuelto:
            self.devuelto = True
            return True
        return False
            
    
    
